
#!/bin/bash
service tomcat8 start
